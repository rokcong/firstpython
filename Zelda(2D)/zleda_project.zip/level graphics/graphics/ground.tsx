<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="ground" tilewidth="32" tileheight="32" tilecount="11400" columns="114">
 <image source="tilemap/ground.png" width="3648" height="3200"/>
</tileset>
