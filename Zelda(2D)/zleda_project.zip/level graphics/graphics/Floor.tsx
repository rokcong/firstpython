<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Floor" tilewidth="32" tileheight="32" tilecount="2200" columns="44">
 <image source="tilemap/Floor.png" width="1408" height="1600"/>
</tileset>
